﻿using System;

namespace D_DProjetC_
{
    class Program
    {
        static void Main()
        {
            Menu();
        }

        static void Combat(Personnage monPerso)
        {
            GobelinArcher gobelinArcher = new("Gobelin Archer");
            bool victoire = true;

            while (!gobelinArcher.EstMort())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Un Gobelin Archer apparait !");
                Console.WriteLine();
                gobelinArcher.Attaquer(monPerso);
                Console.WriteLine();
                Console.ReadKey(true);

                if (monPerso.EstMort())
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Vous avez perdu !");
                    Console.WriteLine();
                    Console.ReadKey(true);
                    Menu();
                }

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("A ton tour !");
                Console.WriteLine();
                monPerso.Attaquer(gobelinArcher);
                Console.WriteLine();
                Console.ReadKey(true);
            }

            if (victoire)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Vous avez gagné !");
                Console.WriteLine();
                monPerso.GagnerExperience(5);
                Console.WriteLine("Vous avez gagné 5 points d'expérience !");
                Console.WriteLine();
                Console.WriteLine(monPerso.Caracteristiques());
                Console.ReadKey(true);
                Menu();
            }
        }

        static void Menu()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Bienvenue dans Donjon et dragon");
            Console.WriteLine();
            Console.WriteLine("Choisis ta classe");
            Console.WriteLine("1. Guerrier");
            Console.WriteLine("2. Mage");
            Console.WriteLine("3. Voleur");
            Console.WriteLine("4. Quitter");
            Console.WriteLine();

            switch (Console.ReadLine())
            {
                case "1":
                    Console.WriteLine("Tu as choisi Guerrier !");
                    Console.WriteLine("Choisis le nom de ton personnage :");
                    string nomGuerrier = Console.ReadLine()!;
                    Guerrier guerrier = new(nomGuerrier);
                    Console.WriteLine();
                    Combat(guerrier);
                    break;
                case "2":
                    Console.WriteLine("Tu as choisi Mage !");
                    Console.WriteLine("Choisis le nom de ton personnage :");
                    string nomMage = Console.ReadLine()!;
                    Mage mage = new(nomMage);
                    Console.WriteLine();
                    Combat(mage);
                    break;
                case "3":
                    Console.WriteLine("Tu as choisi Voleur !");
                    Console.WriteLine("Choisis le nom de ton personnage :");
                    string nomVoleur = Console.ReadLine()!;
                    Voleur voleur = new(nomVoleur);
                    Console.WriteLine();
                    Combat(voleur);
                    break;
                case "4":
                    Environment.Exit(0);
                    break;
                default:
                    Menu();
                    break;
            }
        }
    }
}
